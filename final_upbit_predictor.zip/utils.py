# utils.py
def calculate_rsi(data):
    pass  # RSI 계산 로직